﻿using DwaKolka.Application.DTOs;
using DwaKolka.Application.Serwis;
using Microsoft.AspNetCore.Mvc;

namespace DwaKolka.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoweryController : ControllerBase
    {
        private readonly RowerSerwis _rowerSerwis;

        public RoweryController(RowerSerwis rowerSerwis)
        {
            _rowerSerwis = rowerSerwis;
        }

        [HttpGet("dostępne")]
        public async Task<IActionResult> PobierzDostępneRowery()
        {
            var rowery = await _rowerSerwis.PobierzDostępneRowery();
            return Ok(rowery);
        }

        [HttpPost]
        public async Task<IActionResult> DodajNowyRower([FromBody] RowerDTO rowerDto)
        {
            await _rowerSerwis.DodajNowyRower(rowerDto);
            return CreatedAtAction(nameof(PobierzDostępneRowery), new { id = rowerDto.Id }, rowerDto);
        }
    }

}
