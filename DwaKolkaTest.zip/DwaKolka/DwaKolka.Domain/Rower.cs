﻿



namespace DwaKolka.Domain
{
    public class Rower
    {
        public int Id { get; set; }
        public string Nazwa { get; set; }
        public string Typ { get; set; } // np. "Górski", "Miejski", "Elektryczny"
        public string Rozmiar { get; set; } // np. "Mały", "Średni", "Duży"
        public decimal CenaGodzinowa { get; set; }
        public decimal CenaDzienna { get; set; }
        public bool Dostępny { get; set; }

        // Dodatkowe pola można dodać w razie potrzeby
    }


}
