// AvailableBikes.js
import React, { useEffect, useState } from 'react';
import { fetchAvailableBikes } from './api'; // Importuj funkcj� z api.js

const AvailableBikes = () => {
    const [bikes, setBikes] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const loadBikes = async () => {
            try {
                const availableBikes = await fetchAvailableBikes();
                setBikes(availableBikes);
            } catch (err) {
                setError(err.message);
            }
        };

        loadBikes();
    }, []);

    return (
        <div>
            <h1>Dost�pne rowery</h1>
            {error && <p>{error}</p>}
            <ul>
                {bikes.map(bike => (
                    <li key={bike.id}>{bike.name}</li>
                ))}
            </ul>
        </div>
    );
};

export default AvailableBikes;
