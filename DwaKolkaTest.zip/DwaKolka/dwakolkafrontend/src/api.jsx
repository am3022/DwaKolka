// api.js
const API_URL = 'http://localhost:5197/api/rowery'; // Zaktualizuj URL do swojego backendu

export const fetchAvailableBikes = async () => {
    const response = await fetch(`${API_URL}/dost�pne`);
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return await response.json();
};

export const addNewBike = async (bikeData) => {
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(bikeData),
    });
    if (!response.ok) {
        throw new Error('Failed to add bike');
    }
    return await response.json();
};
