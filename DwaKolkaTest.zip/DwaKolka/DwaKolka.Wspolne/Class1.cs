﻿namespace DwaKolka.Wspolne
{
    public class Class1
    {

    }
}
