﻿using DwaKolka.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DwaKolka.Infrastructure.Data
{
    public class DwaKolkaDbContext : DbContext
    {
        public DwaKolkaDbContext(DbContextOptions<DwaKolkaDbContext> options) : base(options) { }

        public DbSet<Rower> Rowery { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("name=ConnectionStrings:DefaultConnection", new MySqlServerVersion(new Version(8, 0, 21)));
        }
    }


}
