﻿using DwaKolka.Domain;
using DwaKolka.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace DwaKolka.Infrastructure.Repozytoria
{
    public interface IRowerRepository
    {
        Task<List<Rower>> PobierzWszystkieAsync();
        Task DodajAsync(Rower rower);
    }

    public class RowerRepository : IRowerRepository
    {
        private readonly DwaKolkaDbContext _context;

        public RowerRepository(DwaKolkaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Rower>> PobierzWszystkieAsync()
        {
            return await _context.Rowery.ToListAsync();
        }

        public async Task DodajAsync(Rower rower)
        {
            await _context.Rowery.AddAsync(rower);
            await _context.SaveChangesAsync();
        }
    }

}
