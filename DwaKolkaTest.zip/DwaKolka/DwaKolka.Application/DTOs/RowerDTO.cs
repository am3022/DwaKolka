﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DwaKolka.Application.DTOs
{
    public class RowerDTO
    {
        public int Id { get; set; }
        public string Nazwa { get; set; }
        public string Typ { get; set; }
        public string Rozmiar { get; set; }
        public decimal CenaGodzinowa { get; set; }
        public decimal CenaDzienna { get; set; }
        public bool Dostępny { get; set; }
    }

}
