﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DinkToPdf;
using DinkToPdf.Contracts;

namespace DwaKolka.Application.Serwis
{
    public class PdfSerwis
    {
        public byte[] GenerujPdf(string html)
        {
            var konwerter = new BasicConverter(new PdfTools());
            var dokument = new HtmlToPdfDocument
            {
                GlobalSettings = new GlobalSettings
                {
                    ColorMode = ColorMode.Color,
                    Orientation = Orientation.Portrait,
                    PaperSize = PaperKind.A4
                },
                Objects = { new ObjectSettings { HtmlContent = html } }
            };

            return konwerter.Convert(dokument);
        }
    }
}
