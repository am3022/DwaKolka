﻿using DwaKolka.Application.DTOs;
using DwaKolka.Domain;
using DwaKolka.Infrastructure.Repozytoria;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DwaKolka.Application.Serwis
{
    public interface IRowerSerwis
    {
        Task<List<RowerDTO>> PobierzDostępneRowery();
        Task DodajNowyRower(RowerDTO rowerDto);
    }

    public class RowerSerwis : IRowerSerwis
    {
        private readonly IRowerRepository _rowerRepository;

        public RowerSerwis(IRowerRepository rowerRepository)
        {
            _rowerRepository = rowerRepository;
        }

        public async Task<List<RowerDTO>> PobierzDostępneRowery()
        {
            var rowery = await _rowerRepository.PobierzWszystkieAsync();
            return rowery
                .Where(r => r.Dostępny)
                .Select(r => new RowerDTO
                {
                    Id = r.Id,
                    Nazwa = r.Nazwa,
                    Typ = r.Typ,
                    Rozmiar = r.Rozmiar,
                    CenaGodzinowa = r.CenaGodzinowa,
                    CenaDzienna = r.CenaDzienna,
                    Dostępny = r.Dostępny
                })
                .ToList();
        }

        public async Task DodajNowyRower(RowerDTO rowerDto)
        {
            var rower = new Rower
            {
                Nazwa = rowerDto.Nazwa,
                Typ = rowerDto.Typ,
                Rozmiar = rowerDto.Rozmiar,
                CenaGodzinowa = rowerDto.CenaGodzinowa,
                CenaDzienna = rowerDto.CenaDzienna,
                Dostępny = rowerDto.Dostępny
            };

            await _rowerRepository.DodajAsync(rower);
        }
    }

}
