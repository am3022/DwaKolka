﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using SendGrid;
using SendGrid.Helpers.Mail;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace DwaKolka.Application.Serwis
{
    public class EmailSerwis
    {
        private readonly string _sendGridApiKey;

        public EmailSerwis(IConfiguration configuration)
        {
            _sendGridApiKey = configuration["SendGrid:ApiKey"];
        }

        public async Task WyslijEmail(string doKogo, string temat, string tresc)
        {
            var klient = new SendGridClient(_sendGridApiKey);
            var wiadomosc = new SendGridMessage()
            {
                From = new EmailAddress("no-reply@dwakolka.pl", "Dwa Kółka"),
                Subject = temat,
                PlainTextContent = tresc,
                HtmlContent = tresc
            };
            wiadomosc.AddTo(new EmailAddress(doKogo));

            await klient.SendEmailAsync(wiadomosc);
        }
    }
}
