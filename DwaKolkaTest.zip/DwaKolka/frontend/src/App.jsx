
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import BikeList from './components/ListaRowerow';
import ReservationForm from './components/FormaRezerwacji';
import AdminDashboard from './components/Admin';
import UserProfile from './components/User';



const App = () => {
   
    return (
        <Router>
            <div className="container">
                <Switch>
                    <Route path="/" exact component={BikeList} />
                    <Route path="/reserve" component={ReservationForm} />
                    <Route path="/profile" component={UserProfile} />
                    <Route path="/admin" component={AdminDashboard} />
                </Switch>
            </div>
        </Router>
    );
};

export default App;


