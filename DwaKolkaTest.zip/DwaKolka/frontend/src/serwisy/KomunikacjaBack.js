import axios from 'axios';

const API_URL = 'http://localhost:5197'; // Upewnij si�, �e adres URL jest zgodny

export const fetchBikes = async () => {
    const response = await axios.get(`${API_URL}/bikes`);
    return response.data;
};

export const createReservation = async (reservation) => {
    const response = await axios.post(`${API_URL}/reservations`, reservation);
    return response.data;
};
