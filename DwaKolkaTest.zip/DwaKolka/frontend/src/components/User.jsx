
const UserProfile = () => {
    // Przyk�adowe dane u�ytkownika
    const user = {
        name: "Jan Kowalski",
        email: "jan.kowalski@example.com",
        bikeId: "12345",
    };

    return (
        <div>
            <h2>Profil U�ytkownika</h2>
            <div className="mb-3">
                <strong>Imi� i nazwisko:</strong> {user.name}
            </div>
            <div className="mb-3">
                <strong>Email:</strong> {user.email}
            </div>
            <div className="mb-3">
                <strong>ID Roweru:</strong> {user.bikeId}
            </div>
        </div>
    );
};

export default UserProfile;
