import React, { useState } from 'react';
import PropTypes from 'prop-types';

const FormaRezerwacji = ({ onReserve, bikes }) => {
    const [date, setDate] = useState('');
    const [bikeId, setBikeId] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onReserve({ bikeId, date });
    };

    return (
        <div className="container">
            <h2 className="my-4">Formularz Rezerwacji</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="reservationDate">Data rezerwacji</label>
                    <input
                        type="date"
                        className="form-control"
                        id="reservationDate"
                        value={date}
                        onChange={e => setDate(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="bikeSelect">Wybierz rower</label>
                    <select
                        className="form-control"
                        id="bikeSelect"
                        value={bikeId}
                        onChange={e => setBikeId(e.target.value)}
                        required
                    >
                        <option value="">-- Wybierz rower --</option>
                        {bikes.map(bike => (
                            <option key={bike.id} value={bike.id}>
                                {bike.name}
                            </option>
                        ))}
                    </select>
                </div>
                <button type="submit" className="btn btn-primary mt-3">Rezerwuj</button>
            </form>
        </div>
    );
};

// Walidacja props
FormaRezerwacji.propTypes = {
    onReserve: PropTypes.func.isRequired, // Zmienna onReserve powinna by� funkcj�
    bikes: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired, // Zak�adam, �e ID jest liczb�
            name: PropTypes.string.isRequired, // Zak�adam, �e nazwa roweru jest stringiem
        })
    ).isRequired, // Zmienna bikes powinna by� tablic�
};

export default FormaRezerwacji;
