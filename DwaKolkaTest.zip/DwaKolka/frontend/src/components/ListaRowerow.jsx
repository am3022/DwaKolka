
import PropTypes from 'prop-types';

const ListaRowerow = ({ bikes }) => {
    return (
        <div className="container">
            <h2 className="my-4">Lista Rower�w</h2>
            <ul className="list-group">
                {bikes.map(bike => (
                    <li className="list-group-item" key={bike.id}>
                        {bike.name} - {bike.type} - {bike.price} z�/h
                    </li>
                ))}
            </ul>
        </div>
    );
};

// Walidacja props
ListaRowerow.propTypes = {
    bikes: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired,    // Zak�adam, �e ID jest liczb�
            name: PropTypes.string.isRequired,   // Zak�adam, �e nazwa roweru jest stringiem
            type: PropTypes.string.isRequired,   // Zak�adam, �e typ roweru jest stringiem
            price: PropTypes.number.isRequired,  // Zak�adam, �e cena jest liczb�
        })
    ).isRequired, // Zmienna bikes powinna by� tablic�
};

export default ListaRowerow;