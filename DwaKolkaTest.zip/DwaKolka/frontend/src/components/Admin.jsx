

const AdminDashboard = () => {
    return (
        <div>
            <h2>Pulpit Administracyjny</h2>
            <p>Witamy w panelu administracyjnym. Tutaj mo�esz zarz�dza� rowerami i rezerwacjami.</p>
            <div>
                <h3>Zarz�dzanie Rowerami</h3>
                <button className="btn btn-primary mb-2">Dodaj Rower</button>
                <button className="btn btn-secondary mb-2">Edytuj Rower</button>
                <button className="btn btn-danger mb-2">Usu� Rower</button>
            </div>
            <div>
                <h3>Rezerwacje</h3>
                <button className="btn btn-primary mb-2">Zobacz Rezerwacje</button>
            </div>
        </div>
    );
};

export default AdminDashboard;
